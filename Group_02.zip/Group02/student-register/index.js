const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = 3000;
const jsonParser = bodyParser.json();
const fileName = 'students.json';

// Load data from file
let rawData = fs.readFileSync(fileName);
let data = JSON.parse(rawData);

app.set('views', 'views');
app.set('view engine', 'hbs');
app.use(express.static('public'));


app.get('/', (request, response) => {
    response.render('home');
});

// This is a RESTful GET web service
app.get('/students', (request, response) => {
    response.send(data);
});

// This is a RESTful POST web service
app.post('/students', jsonParser, (request, response) => {
  let newEntry = request.body
    data = data.filter(item => item.day !== newEntry.day);
    data.push(newEntry)
    fs.writeFileSync(fileName, JSON.stringify(data, null, 2));
    response.end();
});
app.get('/generated', (req, res) => {
    const data = JSON.parse(fs.readFileSync('generated.json'));
    res.json(data);
});

app.post('/generated', jsonParser, (req, res) => {
    try {
        const data = JSON.parse(fs.readFileSync('generated.json'));
        data.push(req.body);
        fs.writeFileSync('generated.json', JSON.stringify(data, null, 2));
        res.json({ message: "Generated timetable saved" });
    } catch (err) {
        console.error("ERROR when saving generated timetable:", err);
        res.status(500).json({ error: "Failed to save" });
    }
});


app.listen(port);
console.log('server listening on port 3000');